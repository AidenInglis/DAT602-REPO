﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GamerSim
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            LoadPlayersList();//load player list

            if (DataAccessUsers.isAdmin)
                Admin_Panel.Visible = true;//sets admin panel visible if the user is an admin
            else
                Admin_Panel.Visible = false;//the opposite to the above.

        }

        public void LoadPlayersList()//for loading the listbox of players
        {
            try
            {
                //get all players from database
                DataAccessUsers dataAccess = new DataAccessUsers();
                List<Player> allPlayers = dataAccess.GetAllPlayers();//from DAO set list of players = all players

                //clear items from listbox
                PlayerListBox.Items.Clear();
                

                //add player name and win to the listbox (per player)
                foreach (var player in allPlayers)
                {
                    string playerInfo = $"Name: {player.Name}, Wins: {player.Wins}";//name and wins in string.
                    PlayerListBox.Items.Add(playerInfo);//add player info to the listbox
                }
            }
            catch (Exception ex)
            {
                //error handling
                MessageBox.Show("Error loading players: " + ex.Message);
            }
        }
        private void Button_createGame_Click(object sender, EventArgs e)
        {
            Game game = new Game();
            game.Show();
            this.Hide();
        }

        private void Button_logOut_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void Button_createUser_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
            this.Hide();
        }

        private void Button_deleteUser_Click(object sender, EventArgs e)//handling for delete button
        {
            if (PlayerListBox.SelectedItem != null)//if exists
            {
                string selectedItem = PlayerListBox.SelectedItem.ToString();//make selected item to string
                string[] splitItem = selectedItem.Split(',');//split string from the ','

                string selectedPlayer = splitItem[0].Split(':')[1].Trim(); //get "user" part from 'Name: user'

                //confirm deletion with message
                DialogResult result = MessageBox.Show($"Are you sure you want to delete player {selectedPlayer}?", "Delete Player", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)//if yes
                {
                    DataAccessAdmins dataAccess = new DataAccessAdmins();//instance of admin DAO
                    string response = dataAccess.DeletePlayer(selectedPlayer);//call method to delete plaer
                    MessageBox.Show(response);//response from DAO

                    LoadPlayersList();//load player list
                }
            }
            else
            {
                MessageBox.Show("Please select a player to delete.");//no player selected
            }
        }

        private void Button_updateUser_Click(object sender, EventArgs e)//handling for update
        {
            if (PlayerListBox.SelectedItem != null)//if playerbox not null
            {
                //get player username from selected item.
                string selectedPlayer = PlayerListBox.SelectedItem.ToString().Split(',')[0].Trim();//split and trim wins:0 from result
                string playerName = selectedPlayer.Split(':')[1].Trim();//trim it to just the username.

                
                DataAccessAdmins dataAccess = new DataAccessAdmins();//instance of admin DAO
                Player player = dataAccess.GetPlayerByName(playerName);//get player username
                
                if (player != null)//if player exists
                {
                    //give details to the UpdateUser form
                    UpdateUser updateUserForm = new UpdateUser(player);//new instance of UpdateUser with the player + details
                    updateUserForm.ShowDialog();//show updated user
                    LoadPlayersList();//update playerlist
                }
                else
                {
                    MessageBox.Show($"Player {playerName} not found in the database.");//user not found
                }
            }
        }
    }
}
