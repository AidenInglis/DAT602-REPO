﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace GamerSim
{
    class DataAccessGame: DataAccessObject
    {
        public string MakeBoard(int pMaxRows, int pMaxCols)//method for making gameboard.
        {
            List<MySqlParameter> lcParameterList = new List<MySqlParameter>//listing max row and col for grid
            {
                new MySqlParameter("@MaxRow", MySqlDbType.Int32) { Value = pMaxRows },
                new MySqlParameter("@MaxCol", MySqlDbType.Int32) { Value = pMaxCols }
            };
            var aDataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "call make_a_board(@MaxRow, @MaxCol)", lcParameterList.ToArray());//call to sql method
            return aDataSet.Tables[0].Rows[0]["MESSAGE"].ToString();//return message from result.
        }


        public List<Tile> GetBoardTiles()
        {
            List<Tile> tiles = new List<Tile>();

            //get all tiles from database
            var dataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "SELECT * FROM tblTile");//sql get all tiles from tblTile.

            foreach (DataRow row in dataSet.Tables[0].Rows)//loop for each row
            {
                Tile tile = new Tile(Convert.ToInt32(row["row"]), Convert.ToInt32(row["col"]))
                {
                    TileType = Convert.ToInt32(row["TileType"])//set tiletype
                };
                tiles.Add(tile);
            }

            return tiles;
        }
        public Tile GetPlayerTile()
        {
            
            string query = "SELECT * FROM tblTile WHERE TileType = 1";//tile where player is
            MySqlCommand cmd = new MySqlCommand(query);

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())//i can't figure out how to instance tile correctly
                {
                    /*return new Tile
                    {
                        Row = reader.GetInt32("row"),
                        Col = reader.GetInt32("col"),
                        TileType = reader.GetInt32("TileType")
                    };*/
                }
            }
            
            return null;
        }
    }
}