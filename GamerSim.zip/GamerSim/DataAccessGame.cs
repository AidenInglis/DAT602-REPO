﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GamerSim
{
    class DataAccessGame: DataAccessObject
    {
        public string MakeBoard(int pMaxRows, int pMaxCols)//method for making gameboard.
        {
            List<MySqlParameter> lcParameterList = new List<MySqlParameter>//listing max row and col for grid
            {
                new MySqlParameter("@MaxRow", MySqlDbType.Int32) { Value = pMaxRows },
                new MySqlParameter("@MaxCol", MySqlDbType.Int32) { Value = pMaxCols }
            };
            var aDataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "call make_a_board(@MaxRow, @MaxCol)", lcParameterList.ToArray());//call to sql method
            return aDataSet.Tables[0].Rows[0]["MESSAGE"].ToString();//return message from result.
        }


        public List<Tile> GetBoardTiles()
        {
            List<Tile> tiles = new List<Tile>();

            //get all tiles from database
            var dataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "SELECT * FROM tblTile");//sql get all tiles from tblTile.

            foreach (DataRow row in dataSet.Tables[0].Rows)//loop for each row
            {
                Tile tile = new Tile(Convert.ToInt32(row["row"]), Convert.ToInt32(row["col"]))
                {
                    TileType = Convert.ToInt32(row["TileType"])//set tiletype
                };
                tiles.Add(tile);
            }

            return tiles;
        }
        public Tile GetPlayerTile()//work in progress
        {
            
            string query = "SELECT * FROM tblTile WHERE TileType = 1";//tile where player is
            MySqlCommand cmd = new MySqlCommand(query);

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())//i can't figure out how to instance tile correctly
                {
                    /*return new Tile
                    {
                        Row = reader.GetInt32("row"),
                        Col = reader.GetInt32("col"),
                        TileType = reader.GetInt32("TileType")
                    };*/
                }
            }
            
            return null;
        }
        public string CreateNewGameInDatabase(int mapID, string CurrentPlayerName)
        {
            // Prep sql list for mapID
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var mapIDParam = new MySqlParameter("@pmapID", MySqlDbType.VarChar, 50)
            {
                Value = mapID//param name
            };
            parameters.Add(mapIDParam);
            var PlayerParam = new MySqlParameter("@pCurrentPlayerName", MySqlDbType.VarChar, 50)
            {
                Value = CurrentPlayerName//param name
            };
            parameters.Add(PlayerParam);

            //call inert statement for creation of game
            var dataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "call CreateNewGameInDatabase(@pmapID, @pCurrentPlayerName);", parameters.ToArray());

            //return response from insert statement
            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }
        public List<Game> GetAllGames()
        {
            List<Game> lcGames = new List<Game>();//list of players

            var aDataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "call GetAllGames()");//call sql method
            lcGames = (from aResult in
                                    DataTableExtensions.AsEnumerable(aDataSet.Tables[0])//linq to set result to games
                         select
                            new Game//get player name and wins
                            {
                                GameID = Convert.ToInt32(aResult["GameID"]),
                                MapID = Convert.ToInt32(aResult["MapID"]),
                                Status = aResult["Status"].ToString()
                            }).ToList();
            return lcGames;//return list
        }
        public string DeleteGame(int gamenow)//method for deleting the game by ID
        {
            // Prepare the SQL parameters
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var gameParam = new MySqlParameter("@pGameID", MySqlDbType.VarChar, 50)
            {
                Value = gamenow//param name
            };
            parameters.Add(gameParam);

            //call delete procedure with GameID
            var dataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "CALL DeleteGame(@pGameID)", parameters.ToArray());

            //return response from delete
            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }

        public string JoinGame(int gamenow, string CurrentPlayerName)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var gameParam = new MySqlParameter("@pGameID", MySqlDbType.VarChar, 50)
            {
                Value = gamenow//param name
            };
            parameters.Add(gameParam);
            var playerParam = new MySqlParameter("@pCurrentPlayerName", MySqlDbType.VarChar, 50)
            {
                Value = CurrentPlayerName//param name
            };
            parameters.Add(playerParam);

            var dataSet = MySqlHelper.ExecuteDataset(MySqlConnection, "CALL JoinGame(@pGameID, @pCurrentPlayerName)", parameters.ToArray());

            //return response from delete
            return dataSet.Tables[0].Rows[0]["Message"].ToString();
        }
    }
}