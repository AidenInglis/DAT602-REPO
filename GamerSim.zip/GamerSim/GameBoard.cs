﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamerSim
{
    public class GameBoard
    {
        public int Rows { get; private set; }
        public int Cols { get; private set; }
        public Tile[,] Tiles { get; private set; }  //array for holdin tiles
        public Player CurrentPlayer { get; private set; }

        public GameBoard(int rows, int cols, Player player)
        {
            Rows = rows;
            Cols = cols;
            CurrentPlayer = player;
            Tiles = new Tile[rows, cols];
            InitializeTiles();//initialise the tiles
        }

        private void InitializeTiles()
        {
            // Initialize the game board with tiles
            for (int r = 0; r < Rows; r++)
            {
                for (int c = 0; c < Cols; c++)
                {
                    Tiles[r, c] = new Tile(r, c); //use tile.tile for this
                }
            }

            //set special tile, like player spawn, monsters, treasure
            PlacePlayer();
            PlaceMonsters();
            PlaceTreasure();
        }

        private void PlacePlayer()
        {
            //assign player starting position
            Tiles[CurrentPlayer.X, CurrentPlayer.Y].SetPlayer(CurrentPlayer);
        }

        private void PlaceMonsters()
        {
            //monster at position (10,10)
            Tiles[9, 9].SetMonster();
        }

        private void PlaceTreasure()
        {
            //randomly place treasure on grid (4)
            Random rand = new Random();
            int treasureCount = 0;
            while (treasureCount < 4)//place treasure until 4
            {
                int randRow = rand.Next(0, Rows);
                int randCol = rand.Next(0, Cols);

                //not already a player or monster tile then...
                if (Tiles[randRow, randCol].IsEmpty())
                {
                    Tiles[randRow, randCol].SetTreasure();
                    treasureCount++;
                }
            }
        }
    }
}
