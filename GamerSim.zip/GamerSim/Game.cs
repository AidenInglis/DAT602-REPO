﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace GamerSim
{
    public partial class Game : Form
    {
        public string Status { get; set; }
        public int MapID { get; set; }
        public int GameID { get; set; }
        public int CurrentGame {  get; set; }
        public Game()
        {
            InitializeComponent();

        }
        private GameBoard gameBoard;//using this temp

        private void Game_Load(object sender, EventArgs e)
        {
            DataAccessObject dataAccess = new DataAccessObject();//admin DAO
            string result = dataAccess.DBConnection();//get connection result
            MessageBox.Show(result);//show the result
            LoadGameBoard();//load the board
        }
        private void QuitButton_Click(object sender, EventArgs e)
        {
            DataAccessUsers dataAccess = new DataAccessUsers();//admin DAO
            dataAccess.QuitGame(Player.CurrentPlayerName);//call DAO function


            Admin admin = new Admin();//instance of admin form
            admin.Show();//show admin
            this.Hide();//hide this
        }

        private void LoadGameBoard()//load the board for the game.
        {
            DataAccessGame dataAccess = new DataAccessGame();//instance of game DAO
            List<Tile> tiles = dataAccess.GetBoardTiles();//get tiles list from DAO

            //set value for dimensions
            int maxRows = 10;
            int maxCols = 10;

            //clear existing rows and columns
            Game_Board_DataGridView.Rows.Clear();
            Game_Board_DataGridView.Columns.Clear();
            

            //set up grid max dimensions
            Game_Board_DataGridView.ColumnCount = maxCols;
            Game_Board_DataGridView.RowCount = maxRows;

            //adjusting column and row sizes to suit my app
            foreach (DataGridViewColumn col in Game_Board_DataGridView.Columns)
            {
                col.Width = 25; //set width of each column
            }

            foreach (DataGridViewRow row in Game_Board_DataGridView.Rows)
            {
                row.Height = 25; //set height of each row
            }

            //`fill the grid with tiles
            foreach (Tile tile in tiles)
            {
                DataGridViewCell cell = Game_Board_DataGridView.Rows[tile.Row - 1].Cells[tile.Col - 1];

                //for each tiletype change the color
                switch (tile.TileType)
                {
                    case 1:
                        cell.Style.BackColor = Color.Green;//green for player
                        break;
                    case 5:
                        cell.Style.BackColor = Color.Red;//red for monster
                        break;
                    case 3:
                        cell.Style.BackColor = Color.Yellow;//yellow for treasure.
                        break;
                    default:
                        cell.Style.BackColor = Color.Gray;//grey for null
                        break;
                }

                //adding the tiletype int to each cell
                cell.Value = tile.TileType.ToString();
            }
        }

        private void MovePlayer(int newRow, int newCol)//for movement
        {
            //if player or grid null
            if (Player.CurrentPlayer == null || Game_Board_DataGridView == null)
            {
                MessageBox.Show("Player or Game Board is not setup.");
                return;
            }
            //movement functionality rework in progress.
        }

        private void MoveButton_Click(object sender, EventArgs e)//move button functionality
        {
            int playerRow = Player.CurrentPlayer.Y;//sets playerRow to the player cords
            int playerCol = Player.CurrentPlayer.X;//sets playerCol to the player cords

            //highlight valid movement tiles
            HighlightValidTiles(playerRow, playerCol);
        }

        private void HighlightValidTiles(int row, int col)
        {
            //reset all tiles first
            ResetTileColors();

            //check 1-tile around player for movement
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int newRow = row + i;
                    int newCol = col + j;

                    if (IsValidTile(newRow, newCol))
                    {
                        //highlight valid movement tiles
                        DataGridViewCell cell = Game_Board_DataGridView.Rows[newRow].Cells[newCol];
                        cell.Style.BackColor = Color.LightBlue;//make selectable tiles lightblue
                        cell.Tag = "Selectable"; //mark as selectable
                    }
                }
            }
        }

        private void GameBoard_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            int selectedCol = e.ColumnIndex;

            if (Game_Board_DataGridView[selectedRow, selectedCol].Tag == "Selectable")//not sure why this has an underline.
            {
                // Move the player to the selected tile
                MovePlayer(selectedRow, selectedCol);//when the cell is clicked it will send these x,y to the move player function

                // Reset all tile highlights
                ResetTileColors();
            }
        }
        private bool IsValidTile(int row, int col)
        {
            return true;//removed this functionality temp as broke other functionality before submission.
        }
        private void ResetTileColors()//handles the tile colours
        {
            foreach (DataGridViewRow row in Game_Board_DataGridView.Rows)//for each row
            {
                foreach (DataGridViewCell cell in row.Cells)//for each cel in the row
                {
                    //cell not null before continuing
                    if (cell.Value != null && int.TryParse(cell.Value.ToString(), out int tileType))
                    {
                        //uses tileType to change the color of each tile.
                        if (tileType == 0)
                        {
                            cell.Style.BackColor = Color.White; //Null tiles
                        }
                        else if (tileType == 5)
                        {
                            cell.Style.BackColor = Color.Red; //Monster tile
                        }
                        else if (tileType == 3)
                        {
                            cell.Style.BackColor = Color.Yellow; //Treasure tile
                        }
                    }
                }
            }
        }
    }
}
