using MySql.Data.MySqlClient;

namespace DAT602_Project
{
    public partial class FirstForm : Form
    {

        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection;
        public FirstForm()
        {
            InitializeComponent();

        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string userName = TxtUsername.Text;
            string password = TxtPassword.Text;
            DialogResult dlgResult = MessageBox.Show(userName+ " clicked!");
        }
    }
}